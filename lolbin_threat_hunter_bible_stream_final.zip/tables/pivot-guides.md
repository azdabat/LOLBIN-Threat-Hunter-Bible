# Pivot Guides – Core MDE Tables

Use this as a global reference when working any LOLBIN detection.

## Core Telemetry

- DeviceProcessEvents
- DeviceFileEvents
- DeviceNetworkEvents
- DeviceRegistryEvents
- DeviceImageLoadEvents
- EmailEvents, UrlClickEvents (if Defender for Office 365 is connected)
- IdentityInfo, IdentityLogonEvents (if identity data is connected)
